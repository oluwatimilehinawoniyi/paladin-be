package com.paladin.coverLetter.service;

public interface CoverletterService {
    public String generate(String category, String candidateName, String companyName, String position);
}
