package com.paladin.common.exceptions;

public class FeatureRequestNotFoundException extends RuntimeException {
    public FeatureRequestNotFoundException(String message) {
        super(message);
    }
}
