package com.paladin.common.enums;

public enum AuthProvider {
    GOOGLE
}
