package com.paladin.common.enums;

public enum ApplicationStatus {
    SENT,
    INTERVIEW,
    REJECTED,
    ACCEPTED,
    FOLLOW_UP
}
